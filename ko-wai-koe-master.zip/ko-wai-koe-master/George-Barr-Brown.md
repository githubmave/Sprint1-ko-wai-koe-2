Where I grew up: Lower Hutt, Wellington
Where my family is from: Lower Hutt, Wellington
My name: George Barr-Brown