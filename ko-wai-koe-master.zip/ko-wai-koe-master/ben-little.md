Where I grew up: Auckland
Where my family is from: My family is also from Auckland 
My name: Ben Little