Where I grew up: I grew up on Aucklands North shore, but spent teen years down south in Wanaka.
Where my family is from: My family is from Auckland, New Zealand.
My name: Lane Wirihana le Prevost-Smith