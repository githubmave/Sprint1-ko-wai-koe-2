Kia ora,

My name is Nat (or Natalie for those of you who like additional syllables).

I am a Wellington native and have explored a few corners of the globe, however even with a great dislike for wind, I find myself unable to part from this Windy City for very long.

My family originate from Holland, my Opa, Cornelius (grandad) spent a few months on a boat to get here - not before asking my Oma (grandma) to follow after only going out on two dates (very simple times). Luckily he left her with a photo of himself, and my oma thought he was handsome enough that the 18,596km journey did not seem like complete insanity (she followed two years later).

Fast forward a few decades, and here I am!