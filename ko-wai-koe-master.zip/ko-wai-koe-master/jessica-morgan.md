Where I grew up:
I grew up in the UK for the first 13 years of my life then came to Auckland and am still here today!
Where my family is from:
My family is all European, my mother is Scottish and my father has Danish and British ancestory.
My name:
My name is Jess :)