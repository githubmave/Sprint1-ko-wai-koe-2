**My name:** Grant Rigby

**Where I grew up:** North Shore, Auckland
**Family Background:** South African
