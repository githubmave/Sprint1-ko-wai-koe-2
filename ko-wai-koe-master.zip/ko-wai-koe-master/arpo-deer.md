__Where I grew up:__ Timaru
__Where my family is from:__ Koukourarata (Ngai Tahu) Frisia (Holland/Nords)
__My name:__ Arpo Deer