Where I grew up: Wellington and Auckland
Where my family is from: Scotland
My name: Richard Graham
