Where I grew up: Te Whanganui a Tara / Wellington
Where my family is from: I am of Samoan and Niuean descent, but my family also comes from Tonga, Fiji and Aotearoa. 
My name: Fetu-o-le-moana Teuila Tamapeau