Ko Karioi Te Maunga
Kawhia Tangata
Aotea Whenua
Whaingaroa Te Moana
Ko te Nehenehenui toku wharawhara
Oparure toku punga wairua

I grew up between Te Kuiti and Raglan
My family is from Te Kuiti and Raglan
My name is Aubrey Te Kanawa
