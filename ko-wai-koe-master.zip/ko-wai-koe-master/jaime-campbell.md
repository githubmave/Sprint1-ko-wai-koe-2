Ko Taupiri tōku maunga
Ko Waikato tōku awa
Ko Tainui tōku waka
Ko Ngati Maniapoto tōku iwi
Ko Campbell, Ko Hetet, Ko Bell, Ko Roberts oku ingoa whanau
Ko Te Tokanganui a noho tōku marae
No Te Kuiti me no Huia ahau
Ko Jaime Ngamihi tōku ingoa
No rei ra
Kia ora koutou
