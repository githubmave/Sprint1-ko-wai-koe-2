Where I Grew Up: Papamoa/Auckland
Where my family's from: Papamoa
My name is: Riki Hoeata