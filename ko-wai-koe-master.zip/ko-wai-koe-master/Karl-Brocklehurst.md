I grew up in Kihikihi, a tiny town 5 mins south of Te Awamutu.
My family is from New Zealand Mum is of Scottish and NZ Europen descent, and my Dad is Māori and European.
Kia ora my name is Karl Kairakau Brocklehurst.
