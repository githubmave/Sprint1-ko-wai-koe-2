Where I grew up: New Zealand, Iraq, Russia and Thailand
Where my family is from: Wellington and Bangkok
My name: Sam Bartos