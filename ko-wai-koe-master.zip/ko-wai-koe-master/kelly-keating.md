**Where I grew up:** I grew up on the south coast of Wellington\
**Where my family is from:** My family are from Ireland. My father comes from Dublin and my mother's family are from Galway and Belfast. Both seperately made their way to NZ before deciding to stay here and eventually meeting each other.\
**My name:** Kelly\
\
Hello :)
