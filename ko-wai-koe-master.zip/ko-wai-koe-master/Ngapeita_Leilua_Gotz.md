ko wai koe? Who are you?
My full name is Ngapeita Matehaere Leilua - Gotz.
I'm 22 years old, born 1996. I grew up in Auckland all my life but my mother and father are from a small town called Taumarunui.
My tribes are Ngati Maniapoto, Ngapuhi, Ngati Haua, Ngati Tuwharetoa and my hapu are Ngati Hekeawai.
I just finished my third year of studying graphic design at Whitecliffe College of Arts & Design this year (2018). 
The reason I was interested in joining DevAcademy's coding course was to merge my graphic design skills with a more relevant career which will be required in the future.
My mother said that it's a job of the future and I can earn some good money if I became a coder.
Thanks for reading my small intro.
Kia ora! :-)