Where I grew up: Hamilton
Where my family is from: Christchurch
My name: Francine Burling-Claridge