I grew up in Levin, spent most of my twenties in Auckland
My family is from the South Island, and the east coast of the North Island.
Ko Billie ahau.