Kia ora koutou!

Ko Tapuae-o-uenuku taku maunga,
Ko Wairau taku awa,
Ko Omaka taku marae,
Ko kurahaupo taku waka,
Ko Rangitane raua ko Ngati Kuia oku iwi,
Ko Keelan Walker taku ingoa,

Tena ra tatou katoa!