Ko Taki timu toku waka
Ko Ter au Aroho toke Marae
Do Motupohue te puke
Ko tea ra a kiwatoku moana
Ko Ngai Tahu, kai tahu, Kati Ma Moe, wataha toku iwi
No Awarua kainga tuturu
Ko Ryan toku tupuna
Ko Errol Ryan toku papa
Ko Glenyis Young toku mama
Ko Sharlene Ryan taku ingoa
Ko Tasman, ko Lareesah, ko Darian oku tamariki
