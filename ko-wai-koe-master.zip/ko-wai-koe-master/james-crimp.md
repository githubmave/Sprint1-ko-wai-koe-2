Where I grew up: Plimmerton and Kapiti

Where my family is from: My father is from Wellington, and my mother is from Paeroa, but they both travelled around a lot before settling down in Wellington

My name: James Crimp
