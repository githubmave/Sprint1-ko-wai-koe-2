Hi team, 
My name in Vincent, but everyone calls me Vince.

I've grown up mostly in Auckland, but i was born in Thames, and have lived a few different places around the middle North Island. Te Awamutu, Paeroa, Tauranga, Hamilton, but always end up back here in Auckland. Its definetly home to me. 
My family is pretty much all kiwi, going back a fairly long way, i cant remember exactly how many generations, but pre-WW1 at the least.