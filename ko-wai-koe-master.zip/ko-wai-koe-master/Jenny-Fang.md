Where I grew up: I grew up in Wuhan, China
Where my family is from: My family is from China
My name: my name is Jenny Fang