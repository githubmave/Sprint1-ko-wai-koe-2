Where I grew up: Zimbabwe
Where my family is from: Zimbabwe
My name: Rebecca Jackson