**Where I grew up:** China
**Where my family is from: **China 
**My name:** Alex Huang