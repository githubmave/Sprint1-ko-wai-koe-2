<html><body>
<h1><strong>Ko Wai Koe?</strong></h1>
<p>Ko Taupiri te maunga, ko Waikato te awa, ko Ngati Whawhakia te hapuu, ko Waahi te marae.</p>

<h1><strong>1. Where I grew up </strong></h1>
<p>Pukekohe</p>

<h1><strong>2. Where my family is from</strong></h1>
<p>All over the Waikato and Tauranga too</p>

<h1><strong>3. My name:</strong>Ari</h1>
</body>
</html>

