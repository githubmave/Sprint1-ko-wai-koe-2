Where I grew up: Tong-yeong city in South Korea
Where my family is from: South Korea
My name: Miju Cho
