Where I grew up: I was born in Pretoria, South Africa, then immigrated to Auckland, New Zealand when I Was 13.
Where my family is from: South Africa
My name: David Jacobus Luttig