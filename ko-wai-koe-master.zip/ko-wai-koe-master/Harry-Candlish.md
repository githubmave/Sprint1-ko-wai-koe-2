Where I grew up: New Zealand
Where my family is from: England
My name: Harry Candlish
